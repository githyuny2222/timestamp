시간표 프로그램입니다.

exe파일이 있는 폴더에 memo.txt 파일과 timetable.txt 파일이 생성됩니다.

종료는 File 메뉴의 Exit를 통해 하셔야 memo가 저장됩니다.

자세한 도움말은 프로그램의 Help 탭에서 확인하실 수 있습니다.